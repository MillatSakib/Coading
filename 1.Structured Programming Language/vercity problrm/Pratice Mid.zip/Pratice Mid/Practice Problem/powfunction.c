//applying power usingg math function
#include <stdio.h>
#include <math.h>
int main(){
    int a;
    a=pow(2,5);
    printf("The value of 2^5 is %d",a);
    return 0;
}
