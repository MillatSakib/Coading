//5.-> take length and width to find out area of a rectangle
#include <stdio.h>
int main(){
    int a,b,c;
    printf("Please enter the length and width of rectangle: ");
    scanf("%d %d",&a,&b);
    c=a*b;
    printf("The area of rectengle is %d",c);
    return 0;
}
