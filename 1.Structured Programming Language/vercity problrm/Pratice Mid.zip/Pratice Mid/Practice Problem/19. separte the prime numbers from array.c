19.-> separte the prime numbers from array
