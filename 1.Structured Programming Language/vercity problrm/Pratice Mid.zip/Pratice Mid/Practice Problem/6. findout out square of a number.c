//6.-> findout out square of a number
#include <stdio.h>
int main(){
    int a;
    printf("Please enter a number for square: ");
    scanf("%d",&a);
    a=a*a;
    printf("The square of the Number is %d",a);
    return 0;
}
