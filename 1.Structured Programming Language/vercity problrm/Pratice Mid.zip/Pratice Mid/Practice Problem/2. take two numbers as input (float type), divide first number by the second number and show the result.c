//2.-> take two numbers as input (float type), divide first number by the second number and show the result

#include <stdio.h>
int main(){
    float a,b,c;
    scanf("%f %f",&a,&b);
    c=a/b;
    printf("The result is %f",c);
    return 0;
}
