//1.-> take two numbers as input and add them
#include <stdio.h>
int main(){
    int a,b,c;
    scanf("%d %d",&a,&b);
    c=a+b;
    printf("The sum is %d",c);
}
